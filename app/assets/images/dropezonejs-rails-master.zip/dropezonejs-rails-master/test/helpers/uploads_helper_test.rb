require 'test_helper'

class UploadsHelperTest < ActionView::TestCase
end
